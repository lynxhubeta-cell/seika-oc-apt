"""Command line interface for the seika-oc package.

Runs only when the user invokes the `oc` command — never at pip install time.
"""
from __future__ import annotations

import argparse
import json
import os
import platform
import re
import shutil
import sqlite3
import subprocess
import sys
import time
import urllib.error
import urllib.request
import zipfile
from pathlib import Path
from typing import TextIO

from . import __version__, ui

REPO = "bd-loser/opencode-bionic"
INSTALL_SCRIPT_URL = f"https://raw.githubusercontent.com/{REPO}/main/install.sh"
LATEST_RELEASE_API = f"https://api.github.com/repos/{REPO}/releases/latest"
PKG_HELPER = "pkg update && pkg upgrade -y"
REPAIR_PKGS = "pkg install -y curl dpkg jq zstd"

BACKUP_ROOT = Path.home() / ".local" / "share" / "oc-backups"
KEEP_BACKUPS = 5

_VERSION_RE = re.compile(r"v?(\d+(?:\.\d+)*)(?:-([0-9A-Za-z.\-]+))?")

_HINTS = [
    ("text file busy", "Close any running opencode session, then run 'oc --force' again."),
    ("no space left", "Free up storage space, then run 'oc --force' again."),
    ("could not resolve host", "Check your internet connection, then run 'oc --force' again."),
    ("unable to locate package", "Run 'pkg update' manually, then try 'oc --force' again."),
]


class InstallError(RuntimeError):
    def __init__(self, code: int, tail: list[str]):
        super().__init__(f"installer exited with code {code}")
        self.code = code
        self.tail = tail


# --------------------------------------------------------------------------- #
# Version detection
# --------------------------------------------------------------------------- #


def _version_key(version: str) -> tuple[tuple[int, ...], int]:
    """Sortable key: stable > same-number prerelease, higher numbers win."""
    match = _VERSION_RE.search(version)
    if not match:
        return (0,), 0
    numbers = tuple(int(part) for part in match.group(1).split("."))
    stable = 0 if match.group(2) else 1
    return numbers, stable


def _installed_version() -> str | None:
    try:
        result = subprocess.run(
            ["opencode", "--version"],
            capture_output=True,
            text=True,
            timeout=30,
        )
    except (FileNotFoundError, subprocess.SubprocessError):
        return None
    if result.returncode != 0:
        return None
    match = _VERSION_RE.search(result.stdout + result.stderr)
    return match.group(0).removeprefix("v") if match else None


def _latest_version() -> str | None:
    request = urllib.request.Request(
        LATEST_RELEASE_API,
        headers={"User-Agent": "seika-oc", "Accept": "application/vnd.github+json"},
    )
    try:
        with urllib.request.urlopen(request, timeout=15) as resp:
            data = json.load(resp)
        tag = data.get("tag_name", "")
        return tag.removeprefix("v") or None
    except (urllib.error.URLError, json.JSONDecodeError, OSError):
        return _latest_via_curl()


def _latest_via_curl() -> str | None:
    if shutil.which("curl") is None:
        return None
    try:
        result = subprocess.run(
            ["curl", "-fsSL", LATEST_RELEASE_API],
            capture_output=True,
            text=True,
            timeout=20,
        )
        if result.returncode != 0:
            return None
        tag = json.loads(result.stdout).get("tag_name", "")
        return tag.removeprefix("v") or None
    except (json.JSONDecodeError, subprocess.SubprocessError):
        return None


def _status(installed: str | None, latest: str | None) -> str:
    installed_txt = f"v{installed}" if installed else "not installed"
    latest_txt = f"v{latest}" if latest else "unknown (network error?)"
    print(f"installed: {installed_txt}")
    print(f"latest:    {latest_txt}")
    if installed and latest:
        if _version_key(installed) < _version_key(latest):
            return "⬆️  update available — run 'oc' to update"
        return "✅ already up to date"
    if installed:
        return "✅ installed (could not check latest version)"
    return "➡️  not installed — run 'oc' to install"


# --------------------------------------------------------------------------- #
# Session safety
# --------------------------------------------------------------------------- #


def _data_dir() -> Path:
    xdg = os.environ.get("XDG_DATA_HOME")
    base = Path(xdg) if xdg else Path.home() / ".local" / "share"
    return base / "opencode"


def _backup_sessions() -> Path | None:
    """Consistent snapshot of opencode's session databases + legacy storage."""
    data = _data_dir()
    dbs = sorted(data.glob("*.db")) if data.is_dir() else []
    legacy = data / "storage"
    if not dbs and not legacy.exists():
        return None

    dest = BACKUP_ROOT / time.strftime("sessions-%Y%m%d-%H%M%S")
    dest.mkdir(parents=True, exist_ok=True)

    for db in dbs:
        target = dest / db.name
        try:
            with sqlite3.connect(f"file:{db}?mode=ro", uri=True) as src, sqlite3.connect(
                target
            ) as dst:
                src.backup(dst)
        except sqlite3.Error as exc:
            print(f"  [!] Could not snapshot {db.name}: {exc}")
            shutil.rmtree(dest, ignore_errors=True)
            raise

    if legacy.exists():
        shutil.copytree(legacy, dest / "storage", dirs_exist_ok=True)

    return dest


def _restore_sessions(backup: Path) -> int:
    """Merge missing session files back; never overwrite newer data."""
    data = _data_dir()
    restored = 0
    for src in sorted(backup.rglob("*")):
        if not src.is_file():
            continue
        dest = data / src.relative_to(backup)
        if dest.exists():
            continue
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dest)
        restored += 1
    return restored


def _prune_backups(keep: int = KEEP_BACKUPS) -> int:
    if not BACKUP_ROOT.exists():
        return 0
    removed = 0
    sessions = sorted(
        p for p in BACKUP_ROOT.iterdir() if p.is_dir() and p.name.startswith("sessions-")
    )
    for old in sessions[:-keep]:
        shutil.rmtree(old, ignore_errors=True)
        removed += 1
    logs = sorted(BACKUP_ROOT.glob("install-*.log"))
    for old in logs[:-keep]:
        old.unlink(missing_ok=True)
    return removed


# --------------------------------------------------------------------------- #
# Running commands with output captured to the log
# --------------------------------------------------------------------------- #


def _capture(
    log: TextIO, cmd: list[str], stdin_data: str | None = None
) -> tuple[int, list[str]]:
    proc = subprocess.Popen(
        cmd,
        stdin=subprocess.PIPE if stdin_data is not None else subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        errors="replace",
    )
    tail: list[str] = []
    try:
        if stdin_data is not None and proc.stdin is not None:
            proc.stdin.write(stdin_data)
            proc.stdin.close()
        assert proc.stdout is not None
        for line in proc.stdout:
            log.write(line)
            log.flush()
            tail = (tail + [line.rstrip()])[-60:]
    finally:
        code = proc.wait()
    return code, tail


def _run_checked(
    log: TextIO, cmd: list[str], stdin_data: str | None = None
) -> None:
    code, tail = _capture(log, cmd, stdin_data)
    if code != 0:
        raise InstallError(code, tail)


def _fetch_install_script() -> str:
    with urllib.request.urlopen(INSTALL_SCRIPT_URL, timeout=60) as resp:
        return resp.read().decode("utf-8", "replace")


def _perform_install(log: TextIO, log_path: Path, skip_upgrade: bool) -> None:
    if not skip_upgrade:
        if shutil.which("pkg") is None:
            log.write("pkg not found; skipping Termux package upgrade\n")
        else:
            with ui.spinning("Updating Termux packages"):
                _run_checked(log, ["bash", "-lc", PKG_HELPER])

    with ui.spinning("Fetching installer & installing opencode"):
        script = _fetch_install_script()
        _run_checked(log, ["bash"], stdin_data=script)


def _install_direct_binary(log: TextIO, latest: str | None) -> None:
    """Last-resort repair: fetch the raw release binary instead of the .deb."""
    if not latest:
        raise RuntimeError("latest version unknown")
    url = f"https://github.com/{REPO}/releases/download/v{latest}/opencode"
    prefix = os.environ.get("PREFIX")
    target = (
        Path(prefix) / "bin" / "opencode"
        if prefix
        else Path.home() / ".local" / "bin" / "opencode"
    )
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_name("opencode.oc-new")
    log.write(f"fallback download: {url}\n")
    with urllib.request.urlopen(url, timeout=600) as resp, tmp.open("wb") as fh:
        shutil.copyfileobj(resp, fh, length=1024 * 256)
    tmp.chmod(0o755)
    tmp.replace(target)
    log.write(f"fallback binary installed at {target}\n")


def _repair(log: TextIO, latest: str | None) -> bool:
    """Deterministic recovery for unexpected install failures."""
    ui.warn(
        "Unexpected error detected — fixing it automatically. "
        "This may take a few minutes…"
    )

    def retry_installer() -> None:
        script = _fetch_install_script()
        _run_checked(log, ["bash"], stdin_data=script)

    def repair_packages() -> None:
        _run_checked(log, ["bash", "-lc", REPAIR_PKGS])

    def direct_binary() -> None:
        _install_direct_binary(log, latest)

    attempts = (
        ("Retrying installer", retry_installer),
        ("Repairing required packages", repair_packages),
        ("Installing standalone binary", direct_binary),
    )
    for label, action in attempts:
        try:
            with ui.spinning(label):
                action()
            ok = True
        except Exception as exc:  # noqa: BLE001
            log.write(f"[repair] step '{label}' failed: {exc}\n")
            ok = False
        if ok and _installed_version() is not None:
            return True
    return False


def _failure_hint(log_path: Path) -> str | None:
    try:
        text = log_path.read_text(encoding="utf-8", errors="replace")[-20000:].lower()
    except OSError:
        return None
    for needle, hint in _HINTS:
        if needle in text:
            return hint
    return None


# --------------------------------------------------------------------------- #
# Support report
# --------------------------------------------------------------------------- #


def _report(installed: str | None, latest: str | None) -> int:
    BACKUP_ROOT.mkdir(parents=True, exist_ok=True)
    report_path = BACKUP_ROOT / time.strftime("report-%Y%m%d-%H%M%S.txt")
    logs = sorted(BACKUP_ROOT.glob("install-*.log"))

    lines = [
        "seika-oc support report",
        f"generated: {time.strftime('%Y-%m-%d %H:%M:%S')}",
        f"oc: {__version__}",
        f"python: {sys.version.split()[0]}",
        f"platform: {platform.platform()}",
        f"machine: {platform.machine()}",
        f"prefix: {os.environ.get('PREFIX', 'n/a')}",
        f"opencode installed: {installed or 'not installed'}",
        f"latest release: {latest or 'unknown'}",
        "",
    ]
    if logs:
        lines.append(f"last install log: {logs[-1].name}")
        lines.append("=" * 60)
        try:
            content = logs[-1].read_text(encoding="utf-8", errors="replace").splitlines()
            lines.extend(content[-500:])
        except OSError as exc:
            lines.append(f"could not read log: {exc}")
    else:
        lines.append("no install logs found")

    report_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    ui.ok(f"Support report written: {report_path}")
    print("  Share this file to get help.")
    return 0


# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="oc",
        description="Smart installer/updater for OpenCode on Termux.",
    )
    parser.add_argument(
        "-y", "--yes", action="store_true", help="skips the confirmation prompt"
    )
    parser.add_argument(
        "--force", action="store_true", help="reinstall even if already up to date"
    )
    parser.add_argument(
        "--skip-upgrade", action="store_true", help="skips 'pkg update && pkg upgrade -y'"
    )
    parser.add_argument(
        "--check", action="store_true", help="only show installed vs latest version"
    )
    parser.add_argument(
        "--report", action="store_true", help="write a support report with logs"
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    args = parser.parse_args(argv)

    installed = _installed_version()
    latest = _latest_version()

    if args.report:
        return _report(installed, latest)
    if args.check:
        print(_status(installed, latest))
        return 0

    up_to_date = (
        installed is not None
        and latest is not None
        and _version_key(installed) >= _version_key(latest)
    )
    if up_to_date and not args.force:
        ui.ok(f"opencode v{installed} is already installed (latest: v{latest}).")
        print(f"  {ui.DIM}Run 'oc --force' to reinstall anyway.{ui.RESET}")
        return 0

    target = f"v{latest}" if latest else "latest"
    if installed is None:
        action = f"install opencode {target}"
    elif latest is not None:
        action = f"update opencode v{installed} → {target}"
    else:
        action = f"reinstall opencode v{installed}"

    ui.banner()
    ui.info("installed", f"v{installed}" if installed else "not installed")
    ui.info("latest", target if latest else "unknown (network error?)")
    ui.step("Plan")
    if not args.skip_upgrade:
        print(f"    {ui.CYAN}•{ui.RESET} update Termux packages")
    if installed is not None:
        print(f"    {ui.CYAN}•{ui.RESET} back up opencode sessions")
    print(f"    {ui.CYAN}•{ui.RESET} {action}")
    print(f"    {ui.CYAN}•{ui.RESET} verify installation")
    print()

    if not args.yes:
        try:
            answer = input("  Proceed? [y/N] ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            answer = ""
        if answer not in {"y", "yes"}:
            print("  Aborted.")
            return 1

    BACKUP_ROOT.mkdir(parents=True, exist_ok=True)
    log_path = BACKUP_ROOT / time.strftime("install-%Y%m%d-%H%M%S.log")

    with log_path.open("w", encoding="utf-8", errors="replace") as log:
        log.write(f"seika-oc {__version__} | {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
        log.write(f"installed: {installed or 'none'} | latest: {latest or 'unknown'}\n")

        backup_dir: Path | None = None
        if installed is not None:
            try:
                with ui.spinning("Backing up sessions"):
                    backup_dir = _backup_sessions()
            except KeyboardInterrupt:
                print("\n  Interrupted.")
                return 130
            except Exception as exc:  # noqa: BLE001
                ui.err(f"Could not back up sessions: {exc}")
                print("  Aborting update to protect your sessions.")
                return 1
            if backup_dir is not None:
                log.write(f"sessions backup: {backup_dir}\n")

        install_ok = False
        new_version: str | None = None
        try:
            _perform_install(log, log_path, args.skip_upgrade)
            with ui.spinning("Verifying installation"):
                new_version = _installed_version()
            if new_version is None:
                raise InstallError(-1, ["opencode --version returned nothing"])
            install_ok = True
        except InstallError as exc:
            log.write(f"\n[install] failed with code {exc.code}\n")
            for line in exc.tail[-40:]:
                log.write(f"  | {line}\n")
        except KeyboardInterrupt:
            print("\n  Interrupted.")
            return 130
        except Exception as exc:  # noqa: BLE001
            log.write(f"\n[install] unexpected error: {exc}\n")

        if not install_ok:
            install_ok = _repair(log, latest)
            if install_ok:
                new_version = _installed_version()

        if not install_ok:
            ui.err("Could not complete the installation automatically.")
            hint = _failure_hint(log_path)
            if hint:
                print(f"  {hint}")
            print(f"  Full support log: {log_path}")
            print("  Share it for help: run 'oc --report'")
            if backup_dir is not None:
                print(f"  Sessions backup: {backup_dir}")
            return 1

        restored = 0
        if backup_dir is not None:
            try:
                with ui.spinning("Restoring sessions"):
                    restored = _restore_sessions(backup_dir)
            except Exception as exc:  # noqa: BLE001
                log.write(f"[restore] failed: {exc}\n")
                ui.warn(f"Session restore had a problem: {exc}")
                ui.warn(f"Your backup is safe at: {backup_dir}")

        print()
        if installed is not None and new_version:
            ui.ok(f"opencode updated: v{installed} → v{new_version}")
        elif new_version:
            ui.ok(f"opencode v{new_version} installed")
        else:
            ui.warn("opencode installed, but the version could not be read.")

        if backup_dir is not None:
            if restored:
                ui.ok(f"{restored} missing session file(s) restored from backup.")
            else:
                ui.ok("Sessions preserved (no restore needed).")
            print(f"  {ui.DIM}backup: {backup_dir}{ui.RESET}")

        removed = _prune_backups()
        if removed:
            print(f"  {ui.DIM}pruned {removed} old backup(s){ui.RESET}")
        print(f"  {ui.DIM}log: {log_path}{ui.RESET}")
        return 0
