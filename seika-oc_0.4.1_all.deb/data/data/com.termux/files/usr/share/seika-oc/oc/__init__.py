"""oc — one-command OpenCode installer for Termux."""

__version__ = "0.4.1"
