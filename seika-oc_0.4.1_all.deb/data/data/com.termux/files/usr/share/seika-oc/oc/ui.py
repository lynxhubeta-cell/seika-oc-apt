"""Terminal UI helpers: colors, banner, animated loading bar."""
from __future__ import annotations

import atexit
import os
import sys
import threading
import time
from contextlib import contextmanager


def _color_enabled(stream) -> bool:
    return (
        getattr(stream, "isatty", lambda: False)()
        and "NO_COLOR" not in os.environ
        and os.environ.get("TERM") != "dumb"
    )


_ENABLED = _color_enabled(sys.stdout)

RESET = "\033[0m" if _ENABLED else ""
BOLD = "\033[1m" if _ENABLED else ""
DIM = "\033[2m" if _ENABLED else ""
RED = "\033[31m" if _ENABLED else ""
GREEN = "\033[32m" if _ENABLED else ""
YELLOW = "\033[33m" if _ENABLED else ""
CYAN = "\033[36m" if _ENABLED else ""


def _restore_cursor() -> None:
    if _ENABLED:
        sys.stdout.write("\033[?25h")
        sys.stdout.flush()


if _ENABLED:
    atexit.register(_restore_cursor)


class LoadingBar:
    """Indeterminate animated bar that keeps moving until the task finishes."""

    SPINNER = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"

    def __init__(self, label: str, width: int = 26):
        self.label = label
        self.width = width
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._started = time.monotonic()
        self._cursor_hidden = False

    def start(self) -> None:
        self._started = time.monotonic()
        if not _ENABLED:
            return
        sys.stdout.write("\033[?25l")
        sys.stdout.flush()
        self._cursor_hidden = True
        self._thread = threading.Thread(target=self._animate, daemon=True)
        self._thread.start()

    def _animate(self) -> None:
        index = 0
        segment = 7
        span = max(self.width - segment, 1)
        cycle = span * 2
        while not self._stop.is_set():
            phase = index % cycle
            position = phase if phase <= span else cycle - phase
            bar = "".join(
                "█" if position <= cell < position + segment else "░"
                for cell in range(self.width)
            )
            elapsed = int(time.monotonic() - self._started)
            line = (
                f"\r  {CYAN}{self.SPINNER[index % len(self.SPINNER)]}{RESET} "
                f"{self.label}  {bar}  "
                f"{DIM}{elapsed // 60:02d}:{elapsed % 60:02d}{RESET}"
            )
            sys.stdout.write(line)
            sys.stdout.flush()
            time.sleep(0.08)
            index += 1

    def stop(self, success: bool = True, note: str = "") -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join()
            self._thread = None
        if self._cursor_hidden:
            sys.stdout.write("\r\033[K\033[?25h")
            sys.stdout.flush()
            self._cursor_hidden = False
        mark = f"{GREEN}✓{RESET}" if success else f"{RED}✗{RESET}"
        suffix = f"  {DIM}{note}{RESET}" if note else ""
        print(f"  {mark} {self.label}{suffix}")


@contextmanager
def spinning(label: str):
    """Show a loading bar for the duration of the block."""
    bar = LoadingBar(label)
    bar.start()
    ok = False
    try:
        yield bar
        ok = True
    finally:
        bar.stop(ok)


def banner(title: str = "seika-oc · opencode for Termux") -> None:
    width = len(title) + 4
    print(f"{CYAN}╭{'─' * width}╮{RESET}")
    print(f"{CYAN}│{RESET}  {BOLD}{title}{RESET}  {CYAN}│{RESET}")
    print(f"{CYAN}╰{'─' * width}╯{RESET}")
    print()


def info(label: str, value: str) -> None:
    print(f"  {DIM}{label:<10}{RESET}{value}")


def ok(text: str) -> None:
    print(f"  {GREEN}✓{RESET} {text}")


def warn(text: str) -> None:
    print(f"  {YELLOW}⚠{RESET} {text}")


def err(text: str) -> None:
    print(f"  {RED}✗{RESET} {text}")


def step(text: str) -> None:
    print(f"\n  {CYAN}▸{RESET} {BOLD}{text}{RESET}")
